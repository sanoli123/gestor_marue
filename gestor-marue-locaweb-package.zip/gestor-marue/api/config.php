<?php
// ====== DB credentials (edit only the password on the server) ======
$DB_HOST = 'gestormarue.mysql.dbaas.com.br';
$DB_NAME = 'gestormarue';
$DB_USER = 'gestormarue';
$DB_PASS = 'CHANGE_ME_PASSWORD'; // coloque sua senha aqui e salve no servidor

$FORCE_HTTPS = false; // defina true se quiser forçar HTTPS